<?php

function valid(array $post): array
{
    $validate = [
        'error' => false,
        'success' => false,
        'messages' => [],
    ];



    if (!empty($post['login']) && !empty($post['password']) && !empty($post['firstName']) && !empty($post['lastName'])) {
        $login = trim($post['login']);
        $password = trim($post['password']);
        $firstName = trim($post['firstName']);
        $lastName = trim($post['lastName']);

        $constrains = [
            'login' => 6,
            'password' => 7,
            'firstName' => preg_match("/^[a-zA-Z ]*$/", $firstName),
            'lastName' => preg_match("/^[a-zA-Z ]*$/", $lastName)
        ];


        $validateForm = valigData($login, $password, $firstName, $lastName, $constrains);

        if (!$validateForm['login']) {
            $validate['error'] = true;
            array_push($validate['messages'],
                "логин должен быть длиной не менее чем {$constrains['login']} символов");
        }

        if (!$validateForm['password']) {
            $validate['error'] = true;
            array_push($validate['messages'],
                "пароль должен быть длиной не менее чем {$constrains['password']} символов");
        }

        if (!$validateForm['firstName']) {
            $validate['error'] = true;
            array_push($validate['messages'],
                "имя должно содержать латинские буквы и пробелы!"."<span class='er-nm'>"."{$firstName} неккоректно"."</span>");
        }

        if (!$validateForm['lastName']) {
            $validate['error'] = true;
            array_push($validate['messages'],
                "фамилия должна содержать только латинские буквы и пробелы! "."<span class='er-nm'>"."{$lastName} неккоректно"."</span>");
        }
        if (!$validate['error']){
            $validate['success'] = true;
            array_push($validate['messages'],"Логин:{$login}",
                "Пароль:{$password}",
                "Имя:{$firstName}",
                "Фамилия:{$lastName}"
            );
        }
        return $validate;
    }
    return $validate;

}


function valigData(string $login, string $password,string $firstName,string $lastName,array $constrains): array{

    $validateForm = [
        'login' => true,
        'password' => true,
        'firstName' => true,
        'lastName' => true,
    ];

    if (strlen($login) < $constrains['login']) {
        $validateForm['login'] = false;
    }

    if (strlen($password) < $constrains['password']) {
        $validateForm['password'] = false;
    }

    if (!preg_match('/^[a-z ]++$/ui',$firstName)) {
        $validateForm['firstName'] = false;
    }

    if (!preg_match('/^[a-z]++$/ui',$lastName)) {
        $validateForm['lastName'] = false;
    }

    return $validateForm;

}
